'use strict'


var mysql = require('mysql');

var assert = require('assert');

var connection = mysql.createConnection({

  host: "localhost",
  user: "root", 
  password : "sa72542kib",
  port: 3306,
  database: "customer"
});

function validKeys(user_dict)
{
  var used_keys = ["name", "address", "postalnumber", "postaloffice","createddate", "customertype"];
  var count_checked = 0;
  var numb_required_keys = used_keys.length;
  
  for(var key of Object.keys(user_dict))
  {
    console.log(key.toLowerCase());
    if(used_keys.includes(key.toLowerCase()))
    {
      user_dict[key.toLowerCase()] = user_dict[key];
      const index = used_keys.indexOf(key.toLowerCase());
      if (index > -1) {
        used_keys.splice(index, 1);
        }
      count_checked++;

    }

  }
  
  return {is_valid: numb_required_keys  == count_checked, info: used_keys};
}

function ParseSelect( given_query, method="Get")
{
  assert(method == "Get" || method == "Post", "method parameter should be Get or Post");
  if(method == "Get")
  {
    var keys =  Object.keys(given_query) ;
    var base_string = 'select * from customer';
    if(keys.length == 0)
    {
      return base_string ;
    }
    base_string += " where ";
    console.log("my keys: " + keys);
    var i = 0 ;
    i = 0 ;
    for( var key of keys)
    {
      var added = ` ${key} like '${given_query[key]}%' `;
      base_string += added;
      if( i ==  keys.length - 1 )
      {
        break;
  
      }
      i++ ;
      base_string += "AND";
  
    }
    
  }
  else
  {
     var keys_info = validKeys(given_query);
     console.log(given_query);
    assert(keys_info.is_valid, `You didn't specify "${keys_info.info.join(',')}"`);
    var base_string = `INSERT INTO customer (NAME, ADDRESS, POSTALNUMBER, POSTALOFFICE, CREATEDDATE, CUSTOMERTYPE) VALUES ('${given_query.name}','${given_query.address}','${given_query.postalnumber}','${given_query.postaloffice}','${given_query.createddate}','${given_query.customertype}')`;
    
  }
  
  console.log(base_string);
 
  return base_string ;
}

module.exports = 
{
    fetchTypes: function (req, res) {  
      
      connection.query('select customertypeid, abbreviation, description from customertype', function(error, results, fields){
        if ( error ){
          console.log("error fetch data from types-table: " + error);
          res.statusCode = 500 ;
        
          res.json({serverError: "error in server", msgError: error});
          
        }
        else
        {
          res.statusCode = 200 ;
          res.json(results);
        
        }
    });

    },
    

    fetchAll: function(req, res){
        
      
      let sql_query = ParseSelect(req.query,"Get");
      connection.query(sql_query, function(error, results, fields){
        if ( error ){
          console.log("error fetch data from customer-table: " + error);
          res.statusCode = 500 ;
          
          res.json({serverError: "error in server", msgError: error});
          
        }
        else
        {
          res.statusCode = 200 ;
          res.json(results);
        
        }
      })
    },
    haya: function(req, res){
      res.send(" i found it !")
    },

    create: function(req, res){
      
      
      var insert_sql = ParseSelect(req.body, "Post");
      
      connection.query(insert_sql, function(error, results, fields){
        if ( error ){
          console.log("post data to  customer-table: " + error);
          res.statusCode = 500 ;
          
          res.json({serverError: "error in server", msgError: error});
          
        }
        else
        {
          res.statusCode = 200 ;
          
          res.json("created successfully");
        
        }
      })
    
      
    },

    update: function(req, res){

    },

    delete : function (req, res) {
        res.send("called delete");
    }
}
