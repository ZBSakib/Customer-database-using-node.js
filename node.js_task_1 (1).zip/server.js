
// First install express
// npm install express --save

var express = require('express');
var app=express();

// body-parser is used to parse data from http requests
var bodyParser = require('body-parser');
//  we can use custom router for  our server. usually they are in controllers
var customerController = require('./customerController');

const http = require('http');
const url = require('url');

const hostname = '127.0.0.1';
const port = process.env.PORT || 3003;


//CORS middleware
var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*'); // this allo request from any origin
    res.header('Access-Control-Allow-Origin', 'GET,POST,PUT,DELETE'); // this allows only specific request types
    //res.header('Access-Control-Allow-Headers', 'Content-Type')

    // how to limit requests: 

    next();
}
// CORS rules added:
app.use(allowCrossDomain);

// definition for bodyparser
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(bodyParser.json());
app.use(express.urlencoded({extended: true})); 
app.use(express.json());   

//  this is used to define all the static files web pages css or js files
app.use(express.static('public'));

// REST API Customer
app.route('/Types') // 
    .get(customerController.fetchTypes);


app.route('/Customer')
    .get(customerController.fetchAll)
    .post(customerController.create);

app.route('/Cutomer/:id')
    .put(customerController.update)
    .delete(customerController.delete);
//

var fs = require("fs");
app.get('/', function(request, response){
    // request has all the information from the browser
    // response  has all the information from the server
    // Ps: the page is not fully connected to the server this is just for testing xD
    // use postman to check the tasks :)) 
    response.statusCode = 200;
    fs.readFile("task.html",(err, data)=>{
        response.writeHead(200, {'Content-Type': 'text/html','Content-Length':data.length});
        response.write(data);
        response.end();

    })
    
    

});
app.get('/haya', function(request, response){
    response.statusCode = 200;
    //response.statusCode = 200;
    fs.readFile('test.html',(err, data)=>{
        response.writeHead(200, {'Content-Type': 'text/html','Content-Length':data.length});
        response.write(data);
        response.end();

    })
    
})


app.listen(port, hostname, () => {
  console.log(`Server running AT http://${hostname}:${port}/`);
});