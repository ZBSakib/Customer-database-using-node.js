'use strict'

var mysql = require('mysql');
var assert = require('assert');

var connection = mysql.createConnection({

  host: "localhost",
  user: "root", 
  password : "sa72542kib",
  port: 3306,
  database: "customer"
});

function validKeys(user_dict)
{
  var used_keys = ["name", "address", "postalnumber", "postaloffice", "customertype"];
  var count_checked = 0;
  var numb_required_keys = used_keys.length;
  
  for(var key of Object.keys(user_dict))
  {
    if(used_keys.includes(key.toLowerCase()) )
    {
      if(user_dict[key])
      {
        user_dict[key.toLowerCase()] = user_dict[key];
        const index = used_keys.indexOf(key.toLowerCase());
        if (index > -1) {
          used_keys.splice(index, 1);
          }
        count_checked++;
      }
     

    }

  }
  
  return {is_valid: numb_required_keys  == count_checked, info: used_keys};
}
function ParseSelect( given_query, method="Get")
{
  assert(method == "Get" || method == "Post", "method parameter should be Get or Post");
  if(method == "Get")
  {
    var keys =  Object.keys(given_query) ;
    var base_string = 'select * from customer';
    if(keys.length == 0)
    {
      return base_string ;
    }
    base_string += " where ";
    console.log("my keys: " + keys);
    var i = 0 ;
    i = 0 ;
    for( var key of keys)
    {
      var added = ` ${key} like '${given_query[key]}%' `;
      base_string += added;
      if( i ==  keys.length - 1 )
      {
        break;
  
      }
      i++ ;
      base_string += "AND";
  
    }
    
  }
  else
  {
     var keys_info = validKeys(given_query);
     console.log(given_query);
     if(!keys_info.is_valid)
     {
      response.json({error_status: 500, msg: ` you didn't specify ' ${keys_info.info} ' `});

     }
    var base_string = `INSERT INTO customer (NAME, ADDRESS, POSTALNUMBER, POSTALOFFICE, CREATEDDATE, CUSTOMERTYPE) VALUES ('${given_query.name}','${given_query.address}','${given_query.postalnumber}','${given_query.postaloffice}',curdate(),'${given_query.customertype}')`;
    
  }
  return base_string ;
}

module.exports = 
{
    fetchTypes: function (req, res) {  
      connection.query('select customertypeid, abbreviation, description from customertype', function(error, results, fields){
        if ( error ){
          console.log("error fetch data from types-table: " + error);
          res.statusCode = 500 ;
          res.json({serverError: "error in server", msgError: error});
          
        }
        else
        {
          res.statusCode = 200 ;
          res.json(results);
        
        }
    });

    },
    

    fetchAll: function(req, res){
      var sql_query = ParseSelect(req.query,"Get");
      connection.query(sql_query, function(error, results, fields){
        if ( error ){
          console.log("error fetch data from customer-table: " + error);
          res.statusCode = 500 ;
         
          res.json({serverError: "error in server", msgError: error}); 
        }
        else
        {
          res.statusCode = 200 ;
          res.json(results); 
        }
      })
    },
    haya: function(req, res){
      res.send(" i found it !")
    },
    create: function(req, res){
      
      
      var keys_info = validKeys(req.body); 
      if(!keys_info.is_valid) 
      {
        console.log( ` post operation error:  you didn't specify ' ${keys_info.info} '. `);
       res.json({error_status: 500, msg: ` you didn't specify ' ${keys_info.info} ' `});
 
      }
      else
      {
      var insert_sql = `INSERT INTO customer (NAME, ADDRESS, POSTALNUMBER, POSTALOFFICE, CREATEDDATE, CUSTOMERTYPE) VALUES ('${req.body.name}','${req.body.address}','${req.body.postalnumber}','${req.body.postaloffice}',curdate(),'${req.body.customertype}')`;
      
      connection.query(insert_sql, function(error, results, fields){
        if ( error ){
          console.log("post data to  customer-table: " + error);
          res.statusCode = 500 ;
          
          res.json({serverError: "error in server", msgError: error});
          
        }
        else
        {
          res.statusCode = 200 ;
          res.json("created successfully");
        }
      })
      }
    },

    update: function(req, res){
      var validationInfo = validKeys(req.body); 
      if(!validationInfo.is_valid)
      {
        console.log(`update operation error:  you didn't specify ' ${validationInfo.info} '. `)
        res.json({error_status: 500, msg: ` you didn't specify ' ${validationInfo.info} ' `});
      }
      else
      {
      var update_query = `UPDATE customer SET NAME="${req.body.name}", ADDRESS='${req.body.address}', POSTALNUMBER= ${req.body.postalnumber}, postaloffice="${req.body.postaloffice}", CUSTOMERTYPE= ${req.body.customertype} WHERE customerid=${req.params.id}; `;

       connection.query(update_query, function(error, results, fields){
        if(error)
        {
          console.log("update data to  customer-table: " + error);
          res.statusCode = 500 ;
          res.json({serverError: "error in server", msgError: error});
        }
        else
        {
          res.json({status: 200});
        }
       });
      }
    },

    delete : function (req, res) {
      var delte_query = `DELETE FROM CUSTOMER WHERE CUSTOMERID=${req.params.id}`
      connection.query(delte_query,function(error, resuts, field){
        if(error)
        {
          console.log("error delete: " + error);
          res.statusCode = 500 ;
          res.json({serverError: "error in server", msgError: error});
        }
        else
        {
          res.statusCode = 200 ; 
          res.json({response: 200});
        }
      });
        
    }
}
