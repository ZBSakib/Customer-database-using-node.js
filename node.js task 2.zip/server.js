
var express = require('express');
var app=express();

var bodyParser = require('body-parser');
var customerController = require('./customerController');

const http = require('http');
const url = require('url');

const hostname = '127.0.0.1';
const port = process.env.PORT || 3002;

var allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*'); 
    res.header('Access-Control-Allow-Origin', 'GET,POST,PUT,DELETE'); 
    next();
}
app.use(allowCrossDomain);
app.use(express.urlencoded({extended: true})); 
app.use(express.json());   
app.use(express.static('public'));
app.route('/Types') 
    .get(customerController.fetchTypes);
app.route('/Customer')
    .get(customerController.fetchAll)
    .post(customerController.create);
app.route('/Customer/:id')
    .put(customerController.update)
    .delete(customerController.delete);


var fs = require("fs");
app.get('/', function(request, response){
    response.statusCode = 200;
    fs.readFile("myTest.html",(err, data)=>{
        response.writeHead(200, {'Content-Type': 'text/html','Content-Length':data.length});
        response.write(data);
        response.end();
    })
});
app.get('/haya', function(request, response){
    response.statusCode = 200;
    fs.readFile('test.html',(err, data)=>{
        response.writeHead(200, {'Content-Type': 'text/html','Content-Length':data.length});
        response.write(data);
        response.end();
    })  
})

app.listen(port, hostname, () => {
  console.log(`Server running AT http://${hostname}:${port}/`);
});